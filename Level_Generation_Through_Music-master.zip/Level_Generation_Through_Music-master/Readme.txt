The following document will guide you through the steps required to get timestamps of music :-

	1. Extract the application anywhere on the computer say location D:\Applications\WitnessHarmony
	2. Navigate to the same folder.
	3. Double-click the .exe application "WitnessHarmony".
	4. Click on input file to browse your music.
	5. Then, click on play button.
	6. After that, you can choose from any available format of games.
	7. After it is over you can close the application.
	8. Then, you will get timestamps.txt file saved on your working directory.
	9. Copy the text and apply anywhere you like.
	